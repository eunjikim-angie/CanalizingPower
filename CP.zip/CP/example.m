% Last Updates: 2018-FEB-23 
% Written by Eunji

% Computes regulation power, incapacitating power, and canalizing power of
% master genes in a given Boolean network. It prompts users to input
% Boolean rules for each gene. If not provided, a default set up will be used.

clear all, clc, close all

prompt = {'Total Number of Genes (n):','The Number of Master Genes (master_n):','Observation Size (obs_size):','Select 1 for no-noise, 2 for a specific gene perturbation, 3 for equal perturbation for all the genes, and 4 for random gene perturbations:',...
'Time t (n_steady): ','The Number of Random Generations (n_random):'};
dlg_title = 'Input';
num_lines = 1;
answer = inputdlg(prompt,dlg_title,num_lines);
C=num2cell(str2double(answer));
[n,master_n,obs_size,case_num, n_steady, n_random]=C{:};

if case_num==2
    prompt = {'Index of Perturbed Gene:', 'Perturbation Probability:'};
    dlg_title = 'Input';
    num_lines = 1;
    answer = inputdlg(prompt,dlg_title,num_lines);
    C=num2cell(str2double(answer));
    [noise_gene, noise]=C{:};
elseif case_num==3
    prompt = {'Perturbation Probability: '};
    dlg_title = 'Input';
    num_lines = 1;
    answer = inputdlg(prompt,dlg_title,num_lines);
    C=num2cell(str2double(answer));
    [noise]=C{:};
end
    
switch case_num
    case 1    
        p=ones(1,n); % no noise
    case 2
        p=ones(1,n); % no noise
        p(noise_gene)=noise;
    case 3
        p=ones(1,n)*noise; % no noise
    case 4
        beta_a=2;
        beta_b=200;    
end

nf=ones(1,n); % the number of transition functions per gene

nv= input('Enter the Number of Variables Involved in the Function for Each Gene:\n')
if isempty(nv)
    nv=[2,3,3,... 
        3,2,3,...
        3,3,...
        2,2]; % the number of variables involved in the function
end

F=ones(2^max(nv), length(nv))*(-1);
rule= input(['Enter the Boolean Rule: \n\n'...
    ,'Directions -\n "T" for True,\n "N" for Negation,\n "I" for AND,\n "U" for OR,\n "M" for A AND (NOT B),\n "V" for A OR (NOT B),\n "X" for XOR\n']);

if isempty(rule)
    rule={['T','X'],['N','X','M'],['T','I','I'],...
        ['T','U','U'],['T','M'],['T','X','S','T','W'],...
        ['T','U','M'],['T','M','S','T','W'],...
        ['T','I'],['T','X']};
end

varF= input(['Gene Indices Participated in Boolean Functions for Each Gene (varF): \n\n'...
  ,'For example [4  9  3  1  1  1  1  4  7  7;\n'...
,'             5 10  4  2  3  2  2  5  8  8;\n'...
,'            -1  8  10  3 -1  3  3  6 -1 -1;\n'...
,'            -1 -1 -1 -1 -1 -1 -1 -1 -1 -1]\n']);
 if isempty(varF)
    varF=[4  9  3  1  1  1  1  4  7  7;
          5 10  4  2  3  2  2  5  8  8;
         -1  8  10  3 -1  3  3  6 -1 -1;
         -1 -1 -1 -1 -1 -1 -1 -1 -1 -1];
 end
 
idx= input(['n-th Gene in the varF: \n\n'...
  ,'For example {[1,2],[1,2,3],[1,2,3]'...
  ,'[1,2,3],[2,1],[2,3,1,1,1]'...
  ,'[2,3,1],[2,3,1,1,1]'...
  ,'[1,2],[1,2]}']);

if isempty(idx)
    idx={[1,2],[1,2,3],[1,2,3],...
         [1,2,3],[2,1],[2,3,1,1,1],...
         [2,3,1],[2,3,1,1,1],...
         [1,2],[1,2]};
end 

for j=1:length(nv)
    rule_tmp=rule{1,j};
    idx_tmp=idx{1,j};
    m_tmp=nv(j);
    [tmp_result{1,j},len]= rule2bool(m_tmp, rule_tmp, idx_tmp);
    F(1:len,j)=tmp_result{1,j};
end
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
cij=ones(1,n); % in case of Boolean Networks
[truth_table, c_prob]=truthTable(n,F,varF,nf,nv,cij);

master=1:master_n;
slave=master_n+1:n;
slave_size=length(slave);
% the number of possible combinations of observations(slaves) with the size of obs_size
multi_size=nchoosek(slave_size,obs_size); 
slave_vec=nchoosek(1:slave_size,obs_size);

% initialize cell for par for
mean_multi3_cod=cell(1,n_random);
mean_multi2_cod=cell(1,n_random);
mean_indi_cod=cell(1,n_random);
incap_power_multi=cell(1,n_random);
incap_power_single=cell(1,n_random);
enhan_power_multi=cell(1,n_random);
enhan_power_single=cell(1,n_random);
cp_single=cell(1,n_random);
cp_multi=cell(1,n_random);

con_multi_mtx=cell(master_n, multi_size);
coff_multi_mtx=cell(master_n, multi_size);
con_single_mtx=cell(master_n, slave_size);
coff_single_mtx=cell(master_n, slave_size);

if case_num~=4
    A=pbnA_perturbation(truth_table,c_prob,n,nf,p);
end

N=2^n;
names=dec2bin([0:N-1]');

for ns=1:n_random
   
    if case_num==4
    % case 4. random gene perturabation
        perturb=betarnd(beta_a,beta_b,[1,n]);
        p=ones(1,n).*perturb;
        A=pbnA_perturbation(truth_table,c_prob,n,nf,p);
    end
    
    Dtmp=zeros(1,N);
   
    fill=randi(N);
    filltmp(ns)=fill;
    index=randperm(N,fill);
    r=randi(N,[1,2]);
    value=betarnd(r(1),r(2),[1,fill]);
    Dtmp(index)=value;
    D=Dtmp/sum(Dtmp);
    Dinit(ns,:)=D;
    
    for i=1:n_steady
        Dmtx{ns}(i,:)=D;
        D=D*A;
    end
    gap=abs(diff(Dmtx{ns}));
    gap(gap<10^(-7))=0; % neglect small numbers

    steady_reach_idx=min(find(sum(gap,2)<10^(-7)))+1; % find when the given network reaches the steady-state
    
    if isempty(steady_reach_idx)
        steady_reach_vec(ns)=0;
    else
        steady_reach_vec(ns)=steady_reach_idx;
    end
    
end

parfor ns=1:n_random
%for ns=1:n_random
     
    for nstead=1:n_steady
    
    JPD=Dmtx{ns}(nstead,:);

%%% Regulation Power(RP) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [multi_cod,multi_var_cell]=cod(master,slave,obs_size,JPD,n);

    % Compute the Mean-CoD when multiple predictors are employed.
    if (obs_size==3)
        mean_multi3_cod{ns}(nstead,:)=sum(multi_cod,1)/multi_size;
    elseif (obs_size==2)
        mean_multi2_cod{ns}(nstead,:)=sum(multi_cod,1)/multi_size;
    end
    
    % Compute the Mean-CoD when a single predictor is employed.
    [indi_cod,indi_var_cell]=cod(master,slave,1,JPD,n);
    mean_indi_cod{ns}(nstead,:)=sum(indi_cod,1)/slave_size;
    
%%% Incapacitating Power(IP) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Conditioned on each master gene, compute multi-CoD
    for c=1:master_n
        [c_off, c_on, ip, ep]=IP(c, master, slave, obs_size, JPD, n);
        incap_power_multi{ns}(nstead,c)=ip;
        enhan_power_multi{ns}(nstead,c)=ep;
    end
    
    % Conditioned on each master gene, compute a single-CoD
    for c=1:master_n
        [c_off_single, c_on_single, ip_single, ep_single]=IP(c, master, slave, 1, JPD, n);
        incap_power_single{ns}(nstead,c)=ip_single;
        enhan_power_single{ns}(nstead,c)=ep_single;
    end
    
    end % end of nstead

%%% Canalizing Power(CP) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if(obs_size==3)
        cp_multi{ns}=mean_multi3_cod{ns}+incap_power_multi{ns};
        cp_single{ns}=mean_indi_cod{ns}+incap_power_single{ns};
    else
        cp_multi{ns}=mean_multi2_cod{ns}+incap_power_multi{ns};
        cp_single{ns}=mean_indi_cod{ns}+incap_power_single{ns};
    end
end
    
disp('done')
