function [truth_table, c_prob]=truthTable(n,F,varF,nf,nv,cij)

%%% 2017-JUN-21 %%%
% written by Eunji
% generate a truth table

m=(2^n); % the number of possible states
JPD_input=[dec2bin([0:m-1]) - '0']; % generating all the states

for i=1:size(JPD_input,1)
    x=JPD_input(i,:);
    truth_table(i,:)=pbnNextState_v2(x,F,varF,nf,nv,cij,0);
end
append=[];
for j=1:n
     cij_prob=cij(1:nf(j),j);
     append=[append;cij_prob];
end
c_prob=append;
end