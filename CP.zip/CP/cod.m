function [cod, var_cell]=cod(master, slave, obs_size, total_JPD, total_n)

% 2016-JUN-26 %
% written by Eunji Kim

% master: a vector of indices of master genes
% slave: a vector of indices of slave genes
% obs_size: predictor size
% total_JPD: a vector of joint probability distributions for the state of genes of
% size total_n

master_n=length(master);

for i=1:master_n
    % le: lenght(slave)C_obs_size
    % the number of all possible combinations of predictors of size 'obs_size'
    le=size(nchoosek(1:length(slave),obs_size),1); 
    % var_cell=[target, predictor 1, predictor 2, ...]
    var_cell{1,i}=[master(i)*ones(le,1), reshape(slave(nchoosek(1:length(slave),obs_size)),le,obs_size)]; 
end

for i=1:master_n
    var_mtx=var_cell{1,i};
    for j=1:size(var_mtx,1)
        var_idx=var_mtx(j,:);
        par_JPD=part_JPD(total_n,length(var_idx),var_idx, total_JPD);
        cod(j,i)=CoD_from_JPD( length(var_idx), par_JPD, 1, 2:length(var_idx), obs_size );
    end
end
end