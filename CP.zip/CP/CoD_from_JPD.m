function [ CoD ] = CoD_from_JPD( n, JPD, target, obs, npair )
    
    JPD_input=[dec2bin([0:2^n-1]) - '0']; % generating all the states

    self_target=mgn_from_JPD(JPD_input,JPD,target,1);
    self=min(self_target, 1-self_target);
    
    
    m=2^npair;
    
    bitarray=[dec2bin([0:m-1]) - '0'];

    for i=1:size(bitarray,1)
    
        min_vec(i)=min(mgn_from_JPD(JPD_input,JPD, [target,obs],[0,bitarray(i,:)]),mgn_from_JPD(JPD_input,JPD, [target,obs],[1,bitarray(i,:)]));
       
        %min1=min(mgn_from_JPD(JPD_input,JPD, [target,obs],[0,0]),mgn_from_JPD(JPD_input,JPD, [target,obs],[1,0]));
        %min2=min(mgn_from_JPD(JPD_input,JPD, [target,obs],[0,1]),mgn_from_JPD(JPD_input,JPD, [target,obs],[1,1]));
    
        %syn=min1+min2;
    end
    syn=sum(min_vec);
    
    self(self<10^(-10))=0;
    syn(syn<10^(-10))=0;
    
    if self==0 && self==syn
        CoD=1;
        %disp('self=0');
    else
        CoD=1-syn/self;
        CoD(CoD<10^(-10))=0;
    end
    
    if isnan(CoD)
        disp('isnan');
    end
end

