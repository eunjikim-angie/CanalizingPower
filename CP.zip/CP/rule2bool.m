function [tmp_result,len] = rule2bool(m, rule, idx)

% Results of a given Boolean rule
% m = the number of inputs
% rule = Boolean rules

% 2017-JUN-26 
% Written by Eunji

JPD_input=[dec2bin([0:(2^m-1)]) - '0'];

for i=1:length(idx)
    tmp=JPD_input(:,idx(i));
    tmp_rule=rule(i);
    
    switch tmp_rule
    case 'T' % do nothing
        tmp_result=tmp;
    case 'N' % invert
        tmp_result=not(tmp);
    case 'I' % AND
        tmp_result=tmp_result & tmp;
    case 'U' % OR
        tmp_result=tmp_result | tmp;
    case 'M' % AND
        tmp_result=tmp_result & not(tmp);
    case 'V' % OR
        tmp_result=tmp_result | not(tmp);
    case 'X' % XOR
        tmp_result=bitxor(tmp_result, tmp);
    case 'S'
        term1=tmp_result;
    case 'W'
        tmp_result;
        tmp_result=tmp_result | term1;   
    case 'Z'
        tmp_result=tmp_result & term1; 
    case 'O'
        tmp_result=tmp.*0;
            
    end
end
    len=length(tmp_result);
end