function [c_off_cod,c_on_cod,ip, ep]=IP(can_id,master,slave,obs_size, total_JPD, total_n)

% 2017-JUN-26 
% Last modified 2017-JUN-28

% can_id: index of the gene assumed to be a canalizer
% master: a vector of master gene indices.
% slave: a vector of slave gene indices
% obs_size: the size of the observation used for prediction
% total_JPD: a vector of the joint probabilities with the length of total_n

c_off_cod=0;
c_on_cod=0;
c=master(can_id);

JPD_input=[dec2bin([0:2^total_n-1]) - '0']; % generating all the states
off_idx=find(JPD_input(:,c)==0);
on_idx=find(JPD_input(:,c)==1);

if can_id==1
    master=master(2:end);
else
    master=[master(1:can_id-1), master(can_id+1:end)];
end
master_n=length(master);

for i=1:master_n
    le=size(nchoosek(1:length(slave),obs_size),1);
    % [target master gene, slave genes]
    var_cell{1,i}=[master(i)*ones(le,1), reshape(slave(nchoosek(1:length(slave),obs_size)),le,obs_size)];
end

for i=1:master_n
    var_mtx=var_cell{1,i};
    for j=1:size(var_mtx,1)
        var_idx=var_mtx(j,:);
        var_input=var_idx-1;
        var_input(find(var_input==0))=1;
        off_par_JPD=part_JPD(total_n-1,length(var_idx),var_input, total_JPD(off_idx));
        on_par_JPD=part_JPD(total_n-1,length(var_idx),var_input, total_JPD(on_idx));
        c_off_cod(j,i)=CoD_from_JPD( length(var_idx), off_par_JPD, 1, 2:length(var_idx), obs_size );
        c_on_cod(j,i)=CoD_from_JPD( length(var_idx), on_par_JPD, 1, 2:length(var_idx), obs_size );
    end
end
% ip=abs(c_off_cod-c_on_cod);
    delta_CoD=mean(c_off_cod-c_on_cod); % Equation 3.6
    ip=sum(delta_CoD(find(delta_CoD > 0)));
    ep=sum(delta_CoD(find(delta_CoD < 0)))*(-1);
end