function [ mar_p ] = mgn_from_JPD( JPD_input, JPD, var_idx, value )

    %find(JPD_input(:,var)==1);
    %JPD(find(JPD_input(:,var)==1));
    %mar_p=sum(JPD(find(JPD_input(:,var_idx)==1)))
  
    mar_p=sum(JPD(find(ismember(JPD_input(:,var_idx),value,'rows'))));
end

