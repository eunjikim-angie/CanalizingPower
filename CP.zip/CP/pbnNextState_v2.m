function y = pbnNextState_v2(x,F,varF,nf,nv,cij,p)

% y = the row of the truth table when input is x.

% Written Aug 14, 2001 by Ilya Shmulevich;
% Modified May 12, 2003 by HL.
% Modified June 21, 2017 by Eunji

n = length(x);          % number of genes
y = zeros(size(x));     % initialize next state
cnf = [0,cumsum(nf)];
b = 2.^[size(varF,1)-1:-1:0]';
append=[];    
    % Update each node separately.

    for i=1:n
       pmf = cij(1:nf(i),i); % extract its cij probabilities
         for j=1:length(pmf)
            k = cnf(i)+j; % Index of the random selected predictor.
            y = F(x(varF(1:nv(k),k))*b(end-nv(k)+1:end)+1,k); % Output value for the selected function.
            append=[append, y];
         end
    end % for i=1:n
y=append;
end %
