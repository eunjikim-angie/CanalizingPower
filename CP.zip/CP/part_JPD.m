function par_JPD=part_JPD(n,sub_n,var_idx, JPD)
% 2017-JUN-26 %
% Extract a part of JPD from a entire JPD

value_mtx=[dec2bin([0:2^sub_n-1]) - '0']; % generating all the states
JPD_input=[dec2bin([0:2^n-1]) - '0']; % generating all the states

for v=1:size(value_mtx,1)
    value=value_mtx(v,:);
    par_JPD(v)=sum(JPD(find(ismember(JPD_input(:,var_idx),value,'rows'))));
end