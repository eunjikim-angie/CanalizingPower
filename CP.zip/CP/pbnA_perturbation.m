function A=pbnA_perturbation(truth_table,c_prob,n,nf,p)

% Generate a state transition matrix A from a given truth table.
% Output: state transition matrix A.
% Input: 
% truth_table: Truth table
% c_prob: the probability that j-th predictor is used to predict gene i.
% n: the number of genes in the network.
% nf: the number of transition functions per gene.
% p: a vector of size n which contains perturbation probabilites for each
% gene in the network.

% Last Updates: 2017-JUN-22 
% Written by Eunji

K=makeK(nf);
cnf = [0 cumsum(nf)];
m=2^n;

for r=1:m
    for j=1:size(K,1)
        kvec=K(j,:);
        for i=1:n
            chosen_prob(i)=c_prob(cnf(i)+kvec(i));    
            values(j,i)=truth_table(r,cnf(i)+kvec(i));
        end
         prob(j)=prod(chosen_prob);
    end

    bitarray=[dec2bin([0:m-1]) - '0'];
    for a=1:size(values,1)
        for b=1:m
            xor_logic=bitxor(values(a,:),bitarray(b,:));
            prob_mtx(a,b)=prob(a).*prod(p.*xor_logic+(1-p).*(1-xor_logic));
        end
    end
    A(r,:)=sum(prob_mtx,1);
end